package model;

/**
 * An enum class that represents the different types of treasure.
 */
public enum Treasure {
  DIAMOND,
  RUBY,
  SAPPHIRE
}
