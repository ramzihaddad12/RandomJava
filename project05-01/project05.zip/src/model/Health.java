package model;

/**
 * This enum class represents the health of a monster.
 */
public enum Health {
  FULL_HEALTH, HALF_HEALTH, ZERO_HEALTH;
}
