package model;

/**
 * An enum class that represents the smells that
 * a player can experience in the dungeon.
 */
public enum Smell {
  NO_SMELL, PUNGENT, VERY_PUNGENT;
}
